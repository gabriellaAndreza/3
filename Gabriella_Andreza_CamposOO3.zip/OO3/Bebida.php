<?php

abstract class Bebida {
    protected $nome;
    protected $preco;

    public function __construct($nome, $preco) {
        $this->nome = $nome;
        $this->preco = $preco;
    }
    abstract public function mostrarBebida();
    abstract public function verificarPreco($preco);
}
class Vinho extends Bebida {
    private $safra;
    private $tipo;

    public function __construct($nome, $preco, $safra, $tipo) {
        parent::__construct($nome, $preco);
        $this->safra = $safra;
        $this->tipo = $tipo;
    }

    public function mostrarBebida() {
        return "Vinho: " . $this->nome . ", Preço: " . $this->preco . ", Safra: " . $this->safra . ", Tipo: " . $this->tipo;
    }

    public function verificarPreco($preco) {
        return $preco < 25;
    }
}
class Refrigerante extends Bebida {
    private $retornavel;

    public function __construct($nome, $preco, $retornavel) {
        parent::__construct($nome, $preco);
        $this->retornavel = $retornavel;
    }

    public function mostrarBebida() {
        return "Refrigerante: " . $this->nome . ", Preço: " . $this->preco . ", Retornável: " . ($this->retornavel ? 'Sim' : 'Não');
    }

    public function verificarPreco($preco) {
        return $preco < 5;
    }
}

class Suco extends Bebida {
    private $sabor;

    public function __construct($nome, $preco, $sabor) {
        parent::__construct($nome, $preco);
        $this->sabor = $sabor;
    }

    public function mostrarBebida() {
        return "Suco: " . $this->nome . ", Preço: " . $this->preco . ", Sabor: " . $this->sabor;
    }

    public function verificarPreco($preco) {
        return $preco < 2.5;
    }
}
?>

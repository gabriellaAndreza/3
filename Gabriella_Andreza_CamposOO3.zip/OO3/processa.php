<?php
include 'Bebida.php'; 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo'];
    $nome = $_POST['nome'];
    $preco = $_POST['preco'];

    if ($tipo === 'vinho') {
        $safra = $_POST['safra'];
        $tipo_vinho = $_POST['tipo_vinho'];
        $bebida = new Vinho($nome, $preco, $safra, $tipo_vinho);
    } elseif ($tipo === 'refrigerante') {
        $retornavel = $_POST['retornavel'] == '1';
        $bebida = new Refrigerante($nome, $preco, $retornavel);
    } elseif ($tipo === 'suco') {
        $sabor = $_POST['sabor'];
        $bebida = new Suco($nome, $preco, $sabor);
    }

    echo $bebida->mostrarBebida();
}
?>
